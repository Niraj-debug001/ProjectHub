(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_6cef3b70._.js",
  "static/chunks/node_modules_afc705f2._.js"
],
    source: "dynamic"
});
