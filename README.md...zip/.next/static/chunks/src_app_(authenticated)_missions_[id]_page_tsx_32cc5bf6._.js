(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_1ed102fe._.js",
  "static/chunks/node_modules_d5c81265._.js"
],
    source: "dynamic"
});
