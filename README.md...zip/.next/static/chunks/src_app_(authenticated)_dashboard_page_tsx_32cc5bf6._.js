(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_c0efdf8e._.js",
  "static/chunks/node_modules_68f5fb5f._.js"
],
    source: "dynamic"
});
