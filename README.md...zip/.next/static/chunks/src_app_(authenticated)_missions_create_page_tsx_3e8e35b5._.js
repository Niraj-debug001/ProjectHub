(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_9be88ee4._.js",
  "static/chunks/src_b446f0af._.js"
],
    source: "dynamic"
});
