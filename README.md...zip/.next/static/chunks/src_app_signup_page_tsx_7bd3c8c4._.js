(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_6fb75692._.js",
  "static/chunks/node_modules_0fcc9e86._.js"
],
    source: "dynamic"
});
