
import { config } from 'dotenv';
config();

import '@/ai/flows/generate-progress-email-flow.ts';
