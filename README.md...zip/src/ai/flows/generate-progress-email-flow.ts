
'use server';
/**
 * @fileOverview Generates content for a mission progress and task reminder email.
 *
 * - generateProgressEmail - A function that triggers the email content generation.
 * - GenerateProgressEmailInput - The input type for the flow.
 * - GenerateProgressEmailOutput - The return type for the flow.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const PendingTaskSchema = z.object({
  name: z.string().describe('The name of the pending task.'),
  dueDate: z.string().optional().describe('The due date/time for the task (ISO string format). Example: "2024-12-31T23:59:59.000Z" or "Tomorrow 5 PM"'),
});

const GenerateProgressEmailInputSchema = z.object({
  userName: z.string().describe("The name of the email recipient, e.g., 'Admin' or the user's name."),
  missionName: z.string().describe('The name of the mission.'),
  pendingTasks: z.array(PendingTaskSchema).describe('A list of pending tasks for the mission.'),
  completedTasksCount: z.number().describe('The number of tasks completed for the mission.'),
  totalTasksCount: z.number().describe('The total number of tasks for the mission.'),
  overallProgressPercentage: z.number().describe('The overall progress percentage for the mission (0-100).'),
});
export type GenerateProgressEmailInput = z.infer<typeof GenerateProgressEmailInputSchema>;

const GenerateProgressEmailOutputSchema = z.object({
  emailSubject: z.string().describe('The generated subject line for the email.'),
  emailBody: z.string().describe('The generated body content for the email (plain text).'),
});
export type GenerateProgressEmailOutput = z.infer<typeof GenerateProgressEmailOutputSchema>;

export async function generateProgressEmail(input: GenerateProgressEmailInput): Promise<GenerateProgressEmailOutput> {
  return generateProgressEmailFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateProgressEmailPrompt',
  input: {schema: GenerateProgressEmailInputSchema},
  output: {schema: GenerateProgressEmailOutputSchema},
  prompt: `You are an AI assistant helping to draft a progress update email.
The email is for {{{userName}}}.
The email is about the mission titled "{{{missionName}}}".

Current progress:
- Completed Tasks: {{{completedTasksCount}}} out of {{{totalTasksCount}}}
- Overall Progress: {{{overallProgressPercentage}}}%

{{#if pendingTasks.length}}
Pending Tasks (Gentle Reminders):
{{#each pendingTasks}}
- {{this.name}}{{#if this.dueDate}} (Due: {{this.dueDate}}){{/if}}
{{/each}}
{{else}}
All tasks for this mission are currently marked as complete! Excellent work.
{{/if}}

Draft a gentle and encouraging email to {{{userName}}}.
The email should include:
1. A concise and informative subject line for the progress update and task reminder.
2. A friendly greeting.
3. A summary of the progress for "{{{missionName}}}", including the percentage, completed tasks count, and total tasks count.
4. If there are pending tasks, gently remind the user about them, including their due dates if available. List up to 3-4 important pending tasks. If no pending tasks, congratulate them on their excellent progress.
5. An encouraging closing statement.

The email should be formatted as plain text, suitable for a professional but friendly communication.
Keep the tone positive and supportive.
If a due date is an ISO string, try to format it in a more human-readable way, like "December 31, 2024" or "Tomorrow at 5:00 PM", if possible. If it's already human-readable like "Tomorrow 5 PM", use it as is.
`,
});

// Helper function to format ISO date string if needed.
// This is a simple example; a more robust date formatting library could be used.
function formatDueDateForDisplay(isoDate?: string): string | undefined {
  if (!isoDate) return undefined;
  try {
    const date = new Date(isoDate);
    // Check if it's a valid date
    if (isNaN(date.getTime())) return isoDate; // if not parsable, return original

    const today = new Date();
    const tomorrow = new Date();
    tomorrow.setDate(today.getDate() + 1);

    if (date.toDateString() === today.toDateString()) {
      return `Today, ${date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}`;
    }
    if (date.toDateString() === tomorrow.toDateString()) {
      return `Tomorrow, ${date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}`;
    }
    return date.toLocaleDateString([], { year: 'numeric', month: 'long', day: 'numeric' }) + `, ${date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}`;
  } catch (e) {
    return isoDate; // Fallback to original if formatting fails
  }
}

const generateProgressEmailFlow = ai.defineFlow(
  {
    name: 'generateProgressEmailFlow',
    inputSchema: GenerateProgressEmailInputSchema,
    outputSchema: GenerateProgressEmailOutputSchema,
  },
  async (input) => {
    // Format due dates before sending to the prompt for better readability if needed
    const flowInput = {
      ...input,
      pendingTasks: (input.pendingTasks || []).map(task => ({
        ...task,
        dueDate: formatDueDateForDisplay(task.dueDate), // Format for prompt
      })),
    };
    const {output} = await prompt(flowInput);
    return output!;
  }
);
