
"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useForm, useFieldArray } from "react-hook-form";
import * as z from "zod";
import { useRouter } from 'next/navigation';

import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useMissions } from "@/hooks/useMissions";
import type { Mission, MissionStatus, Task } from "@/types";
import { useToast } from "@/hooks/use-toast";
import { PlusCircle, Save, Trash2, XCircle, CalendarIcon } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { format } from "date-fns";
import { cn } from "@/lib/utils";


const missionFormSchema = z.object({
  name: z.string().min(3, { message: "Mission name must be at least 3 characters." }).max(100),
  description: z.string().min(10, { message: "Description must be at least 10 characters." }).max(500),
  status: z.enum(["pending", "active", "completed", "failed"]),
  imageUrl: z.string().url({ message: "Please enter a valid URL for the image." }).optional().or(z.literal('')),
  tasks: z.array(z.object({
    name: z.string().min(1, "Task name cannot be empty."),
    points: z.coerce.number().min(0, "Points must be non-negative."),
    dueDate: z.string().optional(), // ISO string for date
    // Timer fields are managed by context, not directly in form
  })).optional(),
});

type MissionFormValues = z.infer<typeof missionFormSchema>;

interface MissionFormProps {
  mission?: Mission; // For editing existing mission
}

export function MissionForm({ mission }: MissionFormProps) {
  const router = useRouter();
  const { addMission, updateMissionStatus } = useMissions(); // updateMission is not fully implemented for all fields yet
  const { toast } = useToast();

  const defaultValues: Partial<MissionFormValues> = mission
    ? {
        name: mission.name,
        description: mission.description,
        status: mission.status,
        imageUrl: mission.imageUrl,
        tasks: mission.tasks.map(t => ({ name: t.name, points: t.points, dueDate: t.dueDate })) // Exclude timer fields from form defaults
      }
    : { name: "", description: "", status: "pending", imageUrl: "https://placehold.co/600x400.png", tasks: [{name: "", points: 0, dueDate: undefined}] };

  const form = useForm<MissionFormValues>({
    resolver: zodResolver(missionFormSchema),
    defaultValues,
    mode: "onChange",
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "tasks",
  });

  async function onSubmit(data: MissionFormValues) {
    try {
      if (mission) {
        // This is a simplified update, focusing on status.
        // A full update would involve a more comprehensive updateMission function in the context.
        if (data.status !== mission.status) {
            updateMissionStatus(mission.id, data.status as MissionStatus);
        }
        // To fully update tasks, name, description, etc., a dedicated updateMission(mission.id, fullData) function is needed.
        // For now, only status is directly updatable via existing context function easily.
        // The addMission function handles new missions with full task data.
        toast({ title: "Mission Status Updated", description: `${data.name} status has been updated. Other fields require full edit support.` });

      } else {
        addMission({
            name: data.name,
            description: data.description,
            status: data.status as MissionStatus,
            imageUrl: data.imageUrl || 'https://placehold.co/600x400.png',
            tasks: data.tasks?.map(task => ({ // Ensure task objects are correctly structured for addMission
              name: task.name,
              points: task.points,
              completed: false, 
              dueDate: task.dueDate,
              // timeSpentSeconds, timerActive, lastStartTime will be defaulted by addMission in context
            })),
        });
        toast({ title: "Mission Created", description: `${data.name} has been successfully created.` });
      }
      router.push(mission ? `/missions/${mission.id}` : '/missions');
    } catch (error) {
      toast({
        title: "Error",
        description: mission ? "Could not update mission." : "Could not create mission.",
        variant: "destructive",
      });
    }
  }

  return (
    <Card className="max-w-3xl mx-auto shadow-xl">
      <CardHeader>
        <CardTitle className="font-headline text-2xl">{mission ? "Edit Mission" : "Create New Mission"}</CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Mission Name</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., Mars Exploration Alpha" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Detailed description of the mission objectives and scope."
                      rows={5}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
             <FormField
              control={form.control}
              name="imageUrl"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Image URL (Optional)</FormLabel>
                  <FormControl>
                    <Input placeholder="https://placehold.co/600x400.png" {...field} data-ai-hint="planet space" />
                  </FormControl>
                  <FormDescription>URL for the mission's representative image.</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Status</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select mission status" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="failed">Failed</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div>
              <FormLabel className="text-lg font-semibold">Tasks</FormLabel>
              {fields.map((item, index) => (
                <Card key={item.id} className="mt-2 p-4 border rounded-md space-y-3">
                  <FormField
                    control={form.control}
                    name={`tasks.${index}.name`}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm">Task Name</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g., Deploy satellite" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name={`tasks.${index}.points`}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm">Points</FormLabel>
                          <FormControl>
                            <Input type="number" placeholder="e.g., 100" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                        control={form.control}
                        name={`tasks.${index}.dueDate`}
                        render={({ field }) => (
                        <FormItem className="flex flex-col">
                            <FormLabel className="text-sm">Due Date (Optional)</FormLabel>
                            <Popover>
                            <PopoverTrigger asChild>
                                <FormControl>
                                <Button
                                    variant={"outline"}
                                    className={cn(
                                    "pl-3 text-left font-normal",
                                    !field.value && "text-muted-foreground"
                                    )}
                                >
                                    {field.value ? (
                                    format(new Date(field.value), "PPP")
                                    ) : (
                                    <span>Pick a date</span>
                                    )}
                                    <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                                </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                                <Calendar
                                mode="single"
                                selected={field.value ? new Date(field.value) : undefined}
                                onSelect={(date) => field.onChange(date?.toISOString())}
                                disabled={(date) => date < new Date(new Date().setDate(new Date().getDate() -1))} // Disable past dates
                                initialFocus
                                />
                            </PopoverContent>
                            </Popover>
                            <FormMessage />
                        </FormItem>
                        )}
                    />
                  </div>
                  <Button type="button" variant="ghost" size="sm" onClick={() => remove(index)} className="text-destructive hover:bg-destructive/10 float-right">
                    <Trash2 className="mr-1 h-4 w-4" /> Remove Task
                  </Button>
                </Card>
              ))}
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => append({ name: '', points: 0, dueDate: undefined })}
                className="mt-4"
              >
                <PlusCircle className="mr-2 h-4 w-4" /> Add Task
              </Button>
            </div>


            <div className="flex justify-end space-x-3 pt-4">
              <Button type="button" variant="outline" onClick={() => router.back()}>
                <XCircle className="mr-2 h-4 w-4" /> Cancel
              </Button>
              <Button type="submit" disabled={form.formState.isSubmitting}>
                <Save className="mr-2 h-4 w-4" />
                {form.formState.isSubmitting ? "Saving..." : (mission ? "Save Changes" : "Create Mission")}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
