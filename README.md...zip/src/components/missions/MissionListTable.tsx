// src/components/missions/MissionListTable.tsx
"use client";

import Link from 'next/link';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import type { Mission } from '@/types';
import { Eye, Rocket, CheckCircle2, AlertTriangle, Hourglass } from 'lucide-react';
import Image from 'next/image';

interface MissionListTableProps {
  missions: Mission[];
}

const statusIconsAndColors: Record<Mission['status'], { icon: React.ElementType, color: string, textColor: string }> = {
  active: { icon: Rocket, color: 'bg-sky-100', textColor: 'text-sky-700' },
  completed: { icon: CheckCircle2, color: 'bg-green-100', textColor: 'text-green-700' },
  pending: { icon: Hourglass, color: 'bg-yellow-100', textColor: 'text-yellow-700' },
  failed: { icon: AlertTriangle, color: 'bg-red-100', textColor: 'text-red-700' },
};


export function MissionListTable({ missions }: MissionListTableProps) {
  if (missions.length === 0) {
    return <p className="text-center text-muted-foreground py-8">No missions found.</p>;
  }

  return (
    <div className="rounded-lg border shadow-md overflow-hidden bg-card">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[80px]">Image</TableHead>
            <TableHead>Name</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="hidden md:table-cell">Description</TableHead>
            <TableHead className="hidden lg:table-cell">Created At</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {missions.map((mission) => {
            const StatusDisplay = statusIconsAndColors[mission.status] || statusIconsAndColors.pending;
            return (
              <TableRow key={mission.id}>
                 <TableCell>
                  <Image 
                    src={mission.imageUrl || "https://placehold.co/100x100.png"} 
                    alt={mission.name} 
                    width={50} 
                    height={50} 
                    className="rounded-md object-cover"
                    data-ai-hint="spacecraft planet" 
                  />
                </TableCell>
                <TableCell className="font-medium">{mission.name}</TableCell>
                <TableCell>
                  <Badge variant="outline" className={`border-none ${StatusDisplay.color} ${StatusDisplay.textColor}`}>
                    <StatusDisplay.icon className="mr-1.5 h-3.5 w-3.5" />
                    {mission.status.charAt(0).toUpperCase() + mission.status.slice(1)}
                  </Badge>
                </TableCell>
                <TableCell className="hidden md:table-cell max-w-xs truncate">{mission.description}</TableCell>
                <TableCell className="hidden lg:table-cell">{new Date(mission.createdAt).toLocaleDateString()}</TableCell>
                <TableCell className="text-right">
                  <Button asChild variant="ghost" size="sm">
                    <Link href={`/missions/${mission.id}`}>
                      <Eye className="mr-1 h-4 w-4" /> View
                    </Link>
                  </Button>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
}
