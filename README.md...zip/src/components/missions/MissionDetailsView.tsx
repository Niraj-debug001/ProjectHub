
// src/components/missions/MissionDetailsView.tsx
"use client";

import type { Mission, Task as TaskType } from '@/types';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Separator } from '@/components/ui/separator';
import { Rocket, CheckCircle2, AlertTriangle, Hourglass, ListChecks, Edit3, Save, Timer, Play, Pause, RotateCcw } from 'lucide-react';
import Image from 'next/image';
import { useMissions } from '@/hooks/useMissions';
import React, { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import type { MissionStatus } from '@/types';
import { cn } from '@/lib/utils';

interface MissionDetailsViewProps {
  mission: Mission;
}

const statusIcons: Record<Mission['status'], React.ElementType> = {
  active: Rocket,
  completed: CheckCircle2,
  pending: Hourglass,
  failed: AlertTriangle,
};

const statusColors: Record<Mission['status'], string> = {
  active: 'bg-sky-500',
  completed: 'bg-green-500',
  pending: 'bg-yellow-500',
  failed: 'bg-red-500',
};

// Helper to format seconds into HH:MM:SS
const formatTime = (totalSeconds: number): string => {
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
};

interface TaskItemProps {
  task: TaskType;
  missionId: string;
  onToggleCompletion: (taskId: string, completed: boolean) => void;
  onStartTimer: (taskId: string) => void;
  onPauseTimer: (taskId: string) => void;
  onResetTimer: (taskId: string) => void;
  index: number; // Added index for dynamic background
}

const TaskItem: React.FC<TaskItemProps> = ({ task, missionId, onToggleCompletion, onStartTimer, onPauseTimer, onResetTimer, index }) => {
  const [currentTime, setCurrentTime] = useState(task.timeSpentSeconds);

  useEffect(() => {
    let intervalId: NodeJS.Timeout | undefined = undefined;
    if (task.timerActive && task.lastStartTime) {
      const updateDisplayTime = () => {
        const elapsedSinceStart = (Date.now() - new Date(task.lastStartTime!).getTime()) / 1000;
        setCurrentTime(Math.round(task.timeSpentSeconds + elapsedSinceStart));
      };
      updateDisplayTime(); // Initial update
      intervalId = setInterval(updateDisplayTime, 1000);
    } else {
      setCurrentTime(task.timeSpentSeconds);
    }
    return () => clearInterval(intervalId);
  }, [task.timerActive, task.lastStartTime, task.timeSpentSeconds]);

  const taskItemBackgroundClass = task.completed
    ? 'bg-green-100 dark:bg-green-900/30'
    : index % 2 === 0
    ? 'bg-primary/5 hover:bg-primary/10'
    : 'bg-accent/5 hover:bg-accent/10';

  return (
    <li className={cn(
        "flex flex-col p-3 rounded-md border space-y-2 transition-colors",
        taskItemBackgroundClass
      )}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <Checkbox
            id={`task-${task.id}`}
            checked={task.completed}
            onCheckedChange={(checked) => onToggleCompletion(task.id, !!checked)}
            className="mr-3"
            disabled={task.timerActive} // Disable checking off if timer is running
          />
          <Label htmlFor={`task-${task.id}`} className={`text-sm ${task.completed ? 'line-through text-muted-foreground' : ''}`}>
            {task.name} {task.completed && <span className="ml-1">😊</span>}
          </Label>
        </div>
        <Badge variant={task.completed ? "default" : "secondary"} className={task.completed ? "bg-green-500 text-white" : ""}>
          {task.points} pts
        </Badge>
      </div>
      <div className="flex items-center justify-between pl-7 text-xs text-muted-foreground">
        <div className="flex items-center">
          <Timer className="h-3.5 w-3.5 mr-1" />
          <span>Time Spent: {formatTime(currentTime)}</span>
        </div>
        <div className="flex items-center space-x-1">
          {!task.completed && (
            <>
              {task.timerActive ? (
                <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => onPauseTimer(task.id)} title="Pause Timer">
                  <Pause className="h-3.5 w-3.5" />
                </Button>
              ) : (
                <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => onStartTimer(task.id)} title="Start Timer">
                  <Play className="h-3.5 w-3.5" />
                </Button>
              )}
              <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => onResetTimer(task.id)} title="Reset Timer" disabled={task.timerActive}>
                <RotateCcw className="h-3.5 w-3.5" />
              </Button>
            </>
          )}
        </div>
      </div>
       {task.dueDate && (
          <p className="pl-7 text-xs text-muted-foreground">
            Due: {new Date(task.dueDate).toLocaleDateString()}
          </p>
        )}
    </li>
  );
};


export function MissionDetailsView({ mission: initialMission }: MissionDetailsViewProps) {
  const { 
    getMissionById, 
    updateMissionStatus, 
    updateTaskCompletion,
    startTaskTimer,
    pauseTaskTimer,
    resetTaskTimer
  } = useMissions();
  const mission = getMissionById(initialMission.id) || initialMission; 
  const { toast } = useToast();

  const [isEditingStatus, setIsEditingStatus] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState<MissionStatus>(mission.status);

  const Icon = statusIcons[mission.status] || Rocket;
  const completedTasks = mission.tasks.filter(task => task.completed).length;
  const totalTasks = mission.tasks.length;
  const progressPercentage = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;
  
  const handleStatusSave = () => {
    updateMissionStatus(mission.id, selectedStatus);
    setIsEditingStatus(false);
    toast({ title: "Status Updated", description: `Mission status changed to ${selectedStatus}.` });
  };
  
  const handleTaskToggle = (taskId: string, completed: boolean) => {
    updateTaskCompletion(mission.id, taskId, completed);
    const taskName = mission.tasks.find(t => t.id === taskId)?.name || "Task";
    toast({ title: "Task Updated", description: `${taskName} marked as ${completed ? 'complete' : 'incomplete'}. ${completed ? 'Great job! 😊' : ''}` });
  };

  const handleStartTimer = (taskId: string) => {
    startTaskTimer(mission.id, taskId);
    toast({ title: "Timer Started", description: `Timer started for task.` });
  };
  const handlePauseTimer = (taskId: string) => {
    pauseTaskTimer(mission.id, taskId);
    toast({ title: "Timer Paused", description: `Timer paused for task.` });
  };
  const handleResetTimer = (taskId: string) => {
    resetTaskTimer(mission.id, taskId);
    toast({ title: "Timer Reset", description: `Timer reset for task.` });
  };

  return (
    <div className="space-y-6">
      <Card className="shadow-xl overflow-hidden">
        {mission.imageUrl && (
          <div className="relative w-full h-64 md:h-80">
            <Image 
              src={mission.imageUrl} 
              alt={mission.name} 
              fill={true}
              style={{objectFit: "cover"}}
              data-ai-hint="spacecraft mission"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
            <div className="absolute bottom-0 left-0 p-6">
              <Badge variant="secondary" className={`${statusColors[mission.status]} text-white text-sm px-3 py-1.5`}>
                <Icon className="h-4 w-4 mr-2" />
                {mission.status.charAt(0).toUpperCase() + mission.status.slice(1)}
              </Badge>
              <CardTitle className="font-headline text-3xl md:text-4xl text-white mt-2">{mission.name}</CardTitle>
            </div>
          </div>
        )}
        <CardContent className="p-6 space-y-6">
          {!mission.imageUrl && ( 
             <div className="flex justify-between items-center">
                <CardTitle className="font-headline text-3xl">{mission.name}</CardTitle>
                <Badge variant="secondary" className={`${statusColors[mission.status]} text-white`}>
                    <Icon className="h-4 w-4 mr-1.5" />
                    {mission.status.charAt(0).toUpperCase() + mission.status.slice(1)}
                </Badge>
             </div>
          )}

          <div className="grid md:grid-cols-3 gap-6">
            <div className="md:col-span-2 space-y-4">
              <h3 className="text-xl font-semibold text-foreground font-headline">Mission Overview</h3>
              <p className="text-muted-foreground">{mission.description}</p>
              
              <div>
                <Label className="text-xs text-muted-foreground">Created At</Label>
                <p>{new Date(mission.createdAt).toLocaleString()}</p>
              </div>

              {isEditingStatus ? (
                <div className="flex items-end gap-2">
                  <div className="flex-grow">
                    <Label htmlFor="status-select">Update Status</Label>
                    <Select value={selectedStatus} onValueChange={(value) => setSelectedStatus(value as MissionStatus)}>
                      <SelectTrigger id="status-select">
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="completed">Completed</SelectItem>
                        <SelectItem value="failed">Failed</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button onClick={handleStatusSave} size="sm"><Save className="mr-2 h-4 w-4" />Save</Button>
                  <Button onClick={() => setIsEditingStatus(false)} size="sm" variant="outline">Cancel</Button>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                   <Label className="text-xs text-muted-foreground">Current Status:</Label>
                   <p className="font-semibold">{mission.status.charAt(0).toUpperCase() + mission.status.slice(1)}</p>
                  <Button onClick={() => { setSelectedStatus(mission.status); setIsEditingStatus(true); }} variant="ghost" size="sm" className="text-primary hover:text-primary/80">
                    <Edit3 className="mr-1 h-3 w-3" /> Change
                  </Button>
                </div>
              )}
            </div>

            <div className="space-y-4">
              <Card className="bg-secondary/30">
                <CardHeader className="pb-2">
                   <CardTitle className="text-base font-semibold flex items-center"><ListChecks className="h-4 w-4 mr-2 text-primary" /> Task Progress</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between text-sm mb-1">
                    <span>{completedTasks} / {totalTasks} Tasks Completed</span>
                  </div>
                  <Progress value={progressPercentage} aria-label={`${progressPercentage}% tasks completed`} className="h-2.5" />
                </CardContent>
              </Card>
            </div>
          </div>
          
          <Separator />

          <div>
            <h3 className="text-xl font-semibold text-foreground font-headline mb-3 flex items-center"><ListChecks className="h-5 w-5 mr-2 text-primary" /> Tasks Checklist</h3>
            {mission.tasks.length > 0 ? (
              <ul className="space-y-3">
                {mission.tasks.map((task, index) => (
                  <TaskItem
                    key={task.id}
                    task={task}
                    missionId={mission.id}
                    onToggleCompletion={handleTaskToggle}
                    onStartTimer={handleStartTimer}
                    onPauseTimer={handlePauseTimer}
                    onResetTimer={handleResetTimer}
                    index={index} // Pass index here
                  />
                ))}
              </ul>
            ) : (
              <p className="text-muted-foreground">No tasks assigned to this mission.</p>
            )}
          </div>
          
          {mission.status === 'failed' && (
            <Alert variant="destructive" className="mt-6">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Mission Failed</AlertTitle>
              <AlertDescription>
                This mission was marked as failed. Review details.
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
