
// src/components/auth/ForgotPasswordForm.tsx
"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import Link from 'next/link';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { KeyRound, AlertCircle, Loader2, Send, CheckCircle, RotateCcw } from 'lucide-react';

const requestOtpSchema = z.object({
  email: z.string().email("Invalid email address."),
});
type RequestOtpFormValues = z.infer<typeof requestOtpSchema>;

const resetPasswordSchema = z.object({
  otp: z.string().length(6, "OTP must be 6 digits."),
  newPassword: z.string().min(8, "New password must be at least 8 characters."),
  confirmPassword: z.string(),
}).refine(data => data.newPassword === data.confirmPassword, {
  message: "Passwords do not match.",
  path: ["confirmPassword"],
});
type ResetPasswordFormValues = z.infer<typeof resetPasswordSchema>;

export function ForgotPasswordForm() {
  const [step, setStep] = useState(1); // 1: Email, 2: OTP & New Password
  const [formError, setFormError] = useState<string | null>(null);
  const [generatedOtp, setGeneratedOtp] = useState<string | null>(null);
  const [emailForReset, setEmailForReset] = useState<string>("");

  const { resetPassword, checkUserExists, isLoading } = useAuth();
  const router = useRouter();
  const { toast } = useToast();

  const requestOtpForm = useForm<RequestOtpFormValues>({
    resolver: zodResolver(requestOtpSchema),
    defaultValues: { email: "" },
    mode: "onChange",
  });

  const resetPasswordForm = useForm<ResetPasswordFormValues>({
    resolver: zodResolver(resetPasswordSchema),
    defaultValues: { otp: "", newPassword: "", confirmPassword: "" },
    mode: "onChange",
  });

  const handleRequestOtpSubmit = async (data: RequestOtpFormValues) => {
    setFormError(null);
    const userExists = await checkUserExists(data.email);
    if (!userExists) {
      requestOtpForm.setError("email", { type: "manual", message: "No account found with this email address." });
      return;
    }

    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOtp(otp);
    setEmailForReset(data.email);
    console.log(`Simulated OTP for ${data.email}: ${otp}`); // For testing
    toast({
      title: "OTP Sent (Simulated)",
      description: `An OTP has been "sent" to ${data.email}. Check console for OTP: ${otp}`,
      duration: 10000,
    });
    setStep(2);
  };

  const handleResetPasswordSubmit = async (data: ResetPasswordFormValues) => {
    setFormError(null);
    if (!emailForReset || !generatedOtp) {
      setFormError("An unexpected error occurred. Please try again.");
      setStep(1);
      return;
    }

    if (data.otp === generatedOtp) {
      const result = await resetPassword(emailForReset, data.newPassword);
      if (result.success) {
        toast({
          title: "Password Reset Successful!",
          description: "Your password has been changed. Please log in with your new password.",
          variant: "default",
          className: "bg-green-500 text-white",
        });
        router.push('/');
      } else {
        setFormError(result.message || "Failed to reset password. Please try again.");
        resetPasswordForm.resetField("otp");
      }
    } else {
      resetPasswordForm.setError("otp", { type: "manual", message: "Invalid OTP. Please try again." });
    }
  };

  return (
    <Card className="w-full max-w-md shadow-2xl">
      <CardHeader className="text-center">
        <div className="inline-flex justify-center items-center mb-4">
          <KeyRound className="h-10 w-10 text-primary" />
        </div>
        <CardTitle className="font-headline text-3xl">Forgot Password</CardTitle>
        <CardDescription>
          {step === 1 ? "Enter your email to receive a reset OTP." : `Enter OTP and new password for ${emailForReset}.`}
        </CardDescription>
      </CardHeader>
      <CardContent>
        {step === 1 && (
          <Form {...requestOtpForm}>
            <form onSubmit={requestOtpForm.handleSubmit(handleRequestOtpSubmit)} className="space-y-6">
              <FormField control={requestOtpForm.control} name="email" render={({ field }) => (
                <FormItem>
                  <FormLabel>Email Address</FormLabel>
                  <FormControl><Input type="email" placeholder="you@example.com" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              
              {formError && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Error</AlertTitle>
                  <AlertDescription>{formError}</AlertDescription>
                </Alert>
              )}
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Send className="mr-2 h-4 w-4" />}
                {isLoading ? 'Sending...' : 'Send OTP'}
              </Button>
            </form>
          </Form>
        )}

        {step === 2 && (
          <Form {...resetPasswordForm}>
            <form onSubmit={resetPasswordForm.handleSubmit(handleResetPasswordSubmit)} className="space-y-6">
              <FormField control={resetPasswordForm.control} name="otp" render={({ field }) => (
                <FormItem>
                  <FormLabel>Enter OTP</FormLabel>
                  <FormControl><Input type="text" placeholder="Enter 6-digit OTP" {...field} maxLength={6} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={resetPasswordForm.control} name="newPassword" render={({ field }) => (
                <FormItem>
                  <FormLabel>New Password</FormLabel>
                  <FormControl><Input type="password" placeholder="Enter new password" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={resetPasswordForm.control} name="confirmPassword" render={({ field }) => (
                <FormItem>
                  <FormLabel>Confirm New Password</FormLabel>
                  <FormControl><Input type="password" placeholder="Confirm new password" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              
              {formError && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Error</AlertTitle>
                  <AlertDescription>{formError}</AlertDescription>
                </Alert>
              )}

              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <CheckCircle className="mr-2 h-4 w-4" />}
                {isLoading ? 'Resetting...' : 'Reset Password'}
              </Button>
              <Button variant="outline" className="w-full" onClick={() => { setStep(1); setFormError(null); resetPasswordForm.reset(); requestOtpForm.reset(); }}>
                <RotateCcw className="mr-2 h-4 w-4" /> Back to Email Entry
              </Button>
            </form>
          </Form>
        )}
      </CardContent>
      <CardFooter className="flex flex-col items-center text-sm">
        <p className="text-muted-foreground">
          Remembered your password?{' '}
          <Button variant="link" asChild className="p-0 h-auto">
            <Link href="/">Log In</Link>
          </Button>
        </p>
      </CardFooter>
    </Card>
  );
}
