
// src/components/auth/SignupForm.tsx
"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import Link from 'next/link';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { UserPlus, KeyRound, AlertCircle, Loader2, ArrowRight, CheckCircle } from 'lucide-react';
import type { UserSex } from '@/types';

const userDetailsSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters."),
  age: z.coerce.number().min(1, "Age is required.").optional(),
  sex: z.enum(["male", "female", "other", "prefer_not_to_say"]).optional(),
  interests: z.string().optional(),
  profession: z.string().optional(),
  email: z.string().email("Invalid email address."),
  password: z.string().min(8, "Password must be at least 8 characters."),
  confirmPassword: z.string(),
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords do not match.",
  path: ["confirmPassword"],
});

type UserDetailsFormValues = z.infer<typeof userDetailsSchema>;

const otpSchema = z.object({
  otp: z.string().length(6, "OTP must be 6 digits."),
});
type OtpFormValues = z.infer<typeof otpSchema>;


export function SignupForm() {
  const [step, setStep] = useState(1); // 1: Details, 2: OTP
  const [formError, setFormError] = useState<string | null>(null);
  const [generatedOtp, setGeneratedOtp] = useState<string | null>(null);
  const [userDetails, setUserDetails] = useState<UserDetailsFormValues | null>(null);

  const { signup, isLoading } = useAuth();
  const router = useRouter();
  const { toast } = useToast();

  const detailsForm = useForm<UserDetailsFormValues>({
    resolver: zodResolver(userDetailsSchema),
    defaultValues: {
      name: "",
      email: "",
      password: "",
      confirmPassword: "",
      age: undefined,
      sex: undefined,
      interests: "",
      profession: "",
    },
    mode: "onChange",
  });

  const otpForm = useForm<OtpFormValues>({
    resolver: zodResolver(otpSchema),
    defaultValues: { otp: "" },
    mode: "onChange",
  });

  const handleDetailsSubmit = async (data: UserDetailsFormValues) => {
    setFormError(null);
    // Simulate sending OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOtp(otp);
    setUserDetails(data);
    console.log(`Simulated OTP for ${data.email}: ${otp}`); // For testing
    toast({
      title: "OTP Sent (Simulated)",
      description: `An OTP has been "sent" to ${data.email}. Check console for OTP: ${otp}`,
      duration: 10000,
    });
    setStep(2);
  };

  const handleOtpSubmit = async (data: OtpFormValues) => {
    setFormError(null);
    if (!userDetails || !generatedOtp) {
      setFormError("An unexpected error occurred. Please try again.");
      setStep(1); // Go back to details form
      return;
    }

    if (data.otp === generatedOtp) {
      const { password, confirmPassword, ...restOfUserDetails } = userDetails;
      const result = await signup(restOfUserDetails, userDetails.password);
      
      if (result.success) {
        toast({
          title: "Signup Successful!",
          description: "You have been registered. Please log in.",
          variant: "default",
          className: "bg-green-500 text-white",
        });
        router.push('/'); // Redirect to login page
      } else {
        setFormError(result.message || "Signup failed. Please try again.");
        otpForm.reset(); // Reset OTP form
        // Optionally go back to step 1 if email conflict, or allow re-entry of OTP
        // For simplicity, stay on OTP step for now, but show error
         detailsForm.setError("email", {type: "manual", message: result.message});
         setStep(1); // Go back if email exists etc.
      }
    } else {
      otpForm.setError("otp", { type: "manual", message: "Invalid OTP. Please try again." });
    }
  };


  return (
    <Card className="w-full max-w-lg shadow-2xl">
      <CardHeader className="text-center">
         <div className="inline-flex justify-center items-center mb-4">
          <UserPlus className="h-10 w-10 text-primary" />
        </div>
        <CardTitle className="font-headline text-3xl">Create Account</CardTitle>
        <CardDescription>
          {step === 1 ? "Fill in your details to get started." : `Enter the OTP sent to ${userDetails?.email}`}
        </CardDescription>
      </CardHeader>
      <CardContent>
        {step === 1 && (
          <Form {...detailsForm}>
            <form onSubmit={detailsForm.handleSubmit(handleDetailsSubmit)} className="space-y-6">
              <FormField control={detailsForm.control} name="name" render={({ field }) => (
                <FormItem>
                  <FormLabel>Full Name</FormLabel>
                  <FormControl><Input placeholder="John Doe" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={detailsForm.control} name="email" render={({ field }) => (
                <FormItem>
                  <FormLabel>Email Address</FormLabel>
                  <FormControl><Input type="email" placeholder="you@example.com" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField control={detailsForm.control} name="age" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Age (Optional)</FormLabel>
                    <FormControl><Input type="number" placeholder="25" {...field} onChange={e => field.onChange(e.target.value === '' ? undefined : +e.target.value)} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={detailsForm.control} name="sex" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Sex (Optional)</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl><SelectTrigger><SelectValue placeholder="Select sex" /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="male">Male</SelectItem>
                        <SelectItem value="female">Female</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                        <SelectItem value="prefer_not_to_say">Prefer not to say</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
              <FormField control={detailsForm.control} name="interests" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Interests (Optional)</FormLabel>
                    <FormControl><Textarea placeholder="e.g., Space, AI, Reading" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
              )} />
              <FormField control={detailsForm.control} name="profession" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Profession (Optional)</FormLabel>
                    <FormControl><Input placeholder="e.g., Engineer, Scientist" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
              )} />
              <FormField control={detailsForm.control} name="password" render={({ field }) => (
                <FormItem>
                  <FormLabel>Password</FormLabel>
                  <FormControl><Input type="password" placeholder="••••••••" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={detailsForm.control} name="confirmPassword" render={({ field }) => (
                <FormItem>
                  <FormLabel>Confirm Password</FormLabel>
                  <FormControl><Input type="password" placeholder="••••••••" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              {formError && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Signup Failed</AlertTitle>
                  <AlertDescription>{formError}</AlertDescription>
                </Alert>
              )}
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ArrowRight className="mr-2 h-4 w-4" />}
                {isLoading ? 'Processing...' : 'Continue to OTP'}
              </Button>
            </form>
          </Form>
        )}

        {step === 2 && (
          <Form {...otpForm}>
            <form onSubmit={otpForm.handleSubmit(handleOtpSubmit)} className="space-y-6">
              <FormField control={otpForm.control} name="otp" render={({ field }) => (
                <FormItem>
                  <FormLabel>Enter OTP</FormLabel>
                  <FormControl><Input type="text" placeholder="Enter 6-digit OTP" {...field} maxLength={6} /></FormControl>
                  <FormDescription>Check your email (or console for this demo) for the OTP.</FormDescription>
                  <FormMessage />
                </FormItem>
              )} />
              
              {formError && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Verification Failed</AlertTitle>
                  <AlertDescription>{formError}</AlertDescription>
                </Alert>
              )}

              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <CheckCircle className="mr-2 h-4 w-4" />}
                {isLoading ? 'Verifying...' : 'Verify OTP & Sign Up'}
              </Button>
              <Button variant="outline" className="w-full" onClick={() => { setStep(1); setFormError(null); otpForm.reset();}}>
                Back to Details
              </Button>
            </form>
          </Form>
        )}
      </CardContent>
      <CardFooter className="flex flex-col items-center text-sm">
        <p className="text-muted-foreground">
          Already have an account?{' '}
          <Button variant="link" asChild className="p-0 h-auto">
            <Link href="/">Log In</Link>
          </Button>
        </p>
      </CardFooter>
    </Card>
  );
}
