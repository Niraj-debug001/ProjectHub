// src/components/layout/AppSidebar.tsx
"use client";

import { Sidebar, SidebarContent, SidebarHeader, SidebarFooter } from '@/components/ui/sidebar';
import { SidebarNav } from './SidebarNav';
import { AppLogo } from './AppLogo';
import { Button } from '@/components/ui/button';
import { LogOut } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';

export function AppSidebar() {
  const { logout } = useAuth();
  return (
    <Sidebar side="left" collapsible="icon" className="border-r">
        <SidebarHeader className="hidden lg:flex items-center justify-center p-4 border-b">
           {/* Logo and title will be in the content for collapsed view */}
        </SidebarHeader>
        <SidebarContent className="p-2">
          <SidebarNav />
        </SidebarContent>
        <SidebarFooter className="p-2 border-t mt-auto">
           <Button variant="ghost" onClick={logout} className="w-full justify-start text-muted-foreground group-data-[collapsible=icon]:justify-center">
            <LogOut className="mr-2 h-4 w-4 group-data-[collapsible=icon]:mr-0" />
            <span className="group-data-[collapsible=icon]:hidden">Logout</span>
          </Button>
        </SidebarFooter>
    </Sidebar>
  );
}
