
// src/app/page.tsx
import { LoginForm } from '@/components/auth/LoginForm';
import Link from 'next/link';
import { Button } from '@/components/ui/button';

export default function LoginPage() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-8 bg-gradient-to-br from-background to-secondary">
      <LoginForm />
      <div className="mt-6 text-center">
        <p className="text-sm text-muted-foreground">
          Don&apos;t have an account?{' '}
          <Button variant="link" asChild className="p-0 h-auto font-semibold">
            <Link href="/signup">Sign Up</Link>
          </Button>
        </p>
      </div>
    </main>
  );
}
