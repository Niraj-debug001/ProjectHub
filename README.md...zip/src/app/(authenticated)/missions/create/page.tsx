// src/app/(authenticated)/missions/create/page.tsx
import { MissionForm } from '@/components/missions/MissionForm';

export default function CreateMissionPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-headline font-bold text-foreground">Create New Mission</h1>
      <MissionForm />
    </div>
  );
}
