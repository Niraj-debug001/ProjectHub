// src/app/(authenticated)/missions/page.tsx
"use client";

import { useMissions } from '@/hooks/useMissions';
import { MissionListTable } from '@/components/missions/MissionListTable';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { PlusCircle } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

export default function MissionsPage() {
  const { missions, isLoading } = useMissions();

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <Skeleton className="h-10 w-48" />
          <Skeleton className="h-10 w-36" />
        </div>
        <Skeleton className="h-[400px] w-full rounded-lg" />
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-headline font-bold text-foreground">All Missions</h1>
        <Button asChild>
          <Link href="/missions/create">
            <PlusCircle className="mr-2 h-4 w-4" /> Create New Mission
          </Link>
        </Button>
      </div>
      <MissionListTable missions={missions} />
    </div>
  );
}
