
// src/app/(authenticated)/dashboard/page.tsx
"use client";

import { useMissions } from '@/hooks/useMissions';
import { MissionSummaryCard } from '@/components/dashboard/MissionSummaryCard';
import { TimerPanel } from '@/components/dashboard/TimerPanel';
import { TaskReminderWidget } from '@/components/dashboard/TaskReminderWidget';
import { TaskPointsWidget } from '@/components/dashboard/TaskPointsWidget';
import { EmailReportWidget } from '@/components/dashboard/EmailReportWidget';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { PlusCircle, List, Rocket as RocketIconLucide } from 'lucide-react'; // Renamed Rocket to RocketIconLucide
import { Skeleton } from '@/components/ui/skeleton';

export default function DashboardPage() {
  const { missions, isLoading } = useMissions();

  const activeMission = missions.find(m => m.status === 'active') || missions[0]; // Fallback to first mission if no active one
  const recentMissions = missions.slice(0, 3);

  if (isLoading) {
    return (
      <div className="space-y-8">
        <div className="flex justify-between items-center">
          <Skeleton className="h-10 w-48" />
          <Skeleton className="h-10 w-36" />
        </div>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {[...Array(3)].map((_, i) => ( <Skeleton key={i} className="h-72 w-full rounded-lg" /> ))}
        </div>
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-2">
           <Skeleton className="h-64 w-full rounded-lg" />
           <Skeleton className="h-64 w-full rounded-lg" />
        </div>
         <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-3">
           <Skeleton className="h-80 w-full rounded-lg" />
           <Skeleton className="h-80 w-full rounded-lg" />
           <Skeleton className="h-80 w-full rounded-lg" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-headline font-bold text-foreground">Mission Dashboard</h1>
        <div className="flex gap-2">
          <Button asChild>
            <Link href="/missions/create">
              <PlusCircle className="mr-2 h-4 w-4" /> New Mission
            </Link>
          </Button>
          <Button asChild variant="outline">
            <Link href="/missions">
              <List className="mr-2 h-4 w-4" /> All Missions
            </Link>
          </Button>
        </div>
      </div>

      {missions.length === 0 && (
         <div className="text-center py-12">
            <Rocket className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold text-foreground mb-2">No Missions Yet</h3>
            <p className="text-muted-foreground mb-4">Get started by creating your first mission.</p>
            <Button asChild>
              <Link href="/missions/create">
                <PlusCircle className="mr-2 h-4 w-4" /> Create First Mission
              </Link>
            </Button>
          </div>
      )}

      {missions.length > 0 && activeMission && ( // Ensure activeMission exists before rendering dependent components
        <>
          <section>
            <h2 className="text-2xl font-headline font-semibold mb-4 text-foreground">Recent Missions</h2>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {recentMissions.map(mission => (
                <MissionSummaryCard key={mission.id} mission={mission} />
              ))}
            </div>
          </section>

          <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2">
            <TimerPanel />
            <TaskPointsWidget tasks={activeMission.tasks} missionName={activeMission.name} />
          </div>
          
          <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2">
            <TaskReminderWidget tasks={activeMission.tasks} /> {/* Pass active mission tasks */}
            <EmailReportWidget activeMission={activeMission} />
          </div>
          
        </>
      )}
      
      {/* Fallback if missions exist but no activeMission (e.g., all are pending/completed and it's the only one) */}
      {/* This case might be rare if activeMission always falls back to missions[0] */}
      {missions.length > 0 && !activeMission && (
         <div className="text-center py-12">
             <RocketIconLucide className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold text-foreground mb-2">No Active Mission</h3>
            <p className="text-muted-foreground mb-4">There are no active missions to display detailed widgets for. You can view all missions or create a new one.</p>
        </div>
      )}
    </div>
  );
}

// Dummy Rocket icon for when no missions
const Rocket = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"></path><path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.87 12.87 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"></path><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"></path><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"></path></svg>
);
